
import streamlit as st
import pandas as pd

st.set_page_config(page_title="File Download App", layout="centered")

st.title("📥 Streamlit File Download Example")

data = {
    "Name": ["Faisal", "Ali", "John"],
    "Age": [23, 25, 30],
    "City": ["Patna", "Delhi", "Mumbai"]
}

df = pd.DataFrame(data)

st.subheader("Preview Data")
st.dataframe(df)

csv = df.to_csv(index=False).encode('utf-8')

st.download_button(
    label="Download CSV File",
    data=csv,
    file_name="sample_data.csv",
    mime="text/csv"
)
